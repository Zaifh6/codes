import requests
import json
import os
import time
import random
import re
from datetime import datetime
import logging
import sys
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
import socket
from urllib3.connection import HTTPSConnection
from urllib3.connectionpool import HTTPSConnectionPool
from urllib3.poolmanager import PoolManager

# Increase default timeout for all connections
socket.setdefaulttimeout(30)

# Configure console encoding for Windows
if sys.platform == 'win32':
    import ctypes
    kernel32 = ctypes.windll.kernel32
    kernel32.SetConsoleMode(kernel32.GetStdHandle(-11), 7)
    sys.stdout.reconfigure(encoding='utf-8')
    sys.stderr.reconfigure(encoding='utf-8')

# Configure logging - use plain text indicators instead of emojis
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("hadith_scraper.log", encoding='utf-8'),
        logging.StreamHandler()
    ]
)

# File paths
hadith_ids_file = "hadith_ids.txt"
progress_file = 'scraping_progress.json'
json_folder = 'hadith_json_responses'  # Folder for storing JSON responses

# Create folder for JSON responses if it doesn't exist
if not os.path.exists(json_folder):
    os.makedirs(json_folder)
    logging.info(f"Created folder '{json_folder}' for JSON responses")

# API Endpoints
base_endpoints = {
    "hadith_details": "https://hadith.inoor.ir/service/api/elastic/ElasticHadithById",
    "hadith_rejal": "https://hadith.inoor.ir/service/api/hadith/HadithRejalList/v2"
}

# Headers with rotating user agents (simpler to avoid 430 errors)
user_agents = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Safari/605.1.15",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:128.0) Gecko/20100101 Firefox/128.0",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36 Edg/133.0.0.0",
    "Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:127.0) Gecko/20100101 Firefox/127.0"
]

# Proxy settings (set to None if not using proxies)
proxies = None
"""
# Example if you want to use proxies
proxies = {
    "http": "http://your_proxy:port",
    "https": "http://your_proxy:port"
}
"""

# Configure retry strategy for requests with custom backoff
class CustomRetry(Retry):
    def get_backoff_time(self):
        backoff = super().get_backoff_time()
        # Add randomness to backoff time (jitter)
        return backoff + random.uniform(1, 3)

# Configure session with better connection pooling
def get_requests_session(timeout=30):
    session = requests.Session()
    retry_strategy = CustomRetry(
        total=5,
        backoff_factor=2,
        status_forcelist=[429, 500, 502, 503, 504],
        allowed_methods=["GET", "POST"],
        respect_retry_after_header=True
    )
    adapter = HTTPAdapter(
        max_retries=retry_strategy,
        pool_connections=10,
        pool_maxsize=10,
        pool_block=False
    )
    session.mount("http://", adapter)
    session.mount("https://", adapter)
    
    # Set default timeout for all requests in a safer way
    if timeout:
        session.timeout = timeout
    
    # Apply proxies if configured
    if proxies:
        session.proxies.update(proxies)
    
    return session

# Get minimal headers to avoid Error 430 (Request Header Fields Too Large)
def get_minimal_headers():
    return {
        "accept": "application/json",
        "content-type": "application/json",
        "user-agent": random.choice(user_agents),
        "referer": "https://hadith.inoor.ir/"
    }

# Get random headers with more fields (for variety)
def get_random_headers():
    # Decide randomly whether to use minimal or full headers
    if random.random() < 0.7:  # 70% chance of minimal headers
        return get_minimal_headers()
    
    return {
        "accept": "application/json, text/plain, */*",
        "content-type": "application/json",
        "referer": "https://hadith.inoor.ir/",
        "user-agent": random.choice(user_agents),
        "accept-language": "en-US,en;q=0.9",
        "cache-control": "no-cache"
    }

# Function to read hadith IDs from the text file
def read_hadith_ids_from_file():
    hadith_ids = []
    try:
        with open(hadith_ids_file, 'r', encoding='utf-8') as f:
            for line in f:
                hadith_id = line.strip()
                if hadith_id and hadith_id.isdigit():  # Ensure it's a valid number
                    hadith_ids.append(hadith_id)
        
        logging.info(f"Read {len(hadith_ids)} hadith IDs from {hadith_ids_file}")
        return hadith_ids
    except Exception as e:
        logging.error(f"Failed to read hadith IDs from file: {e}")
        return []

# Load or initialize progress tracking
def load_progress():
    if os.path.exists(progress_file):
        try:
            with open(progress_file, 'r', encoding='utf-8') as f:
                data = json.load(f)
                # Initialize consecutive_failures if it doesn't exist
                if 'consecutive_failures' not in data:
                    data['consecutive_failures'] = 0
                if 'header_too_large_errors' not in data:
                    data['header_too_large_errors'] = 0
                if 'delay_factor' not in data:
                    data['delay_factor'] = 1.0
                return data
        except json.JSONDecodeError:
            logging.warning("Progress file corrupted, initializing new progress tracking")
    
    return {
        "completed": [],
        "failed": [],
        "last_processed_index": -1,
        "rate_limit_hits": 0,
        "last_run_timestamp": None,
        "timeout_errors": 0,
        "consecutive_failures": 0,
        "header_too_large_errors": 0,
        "delay_factor": 1.0  # Base delay factor, will adjust dynamically
    }

def save_progress(progress_data):
    progress_data["last_run_timestamp"] = datetime.now().isoformat()
    with open(progress_file, 'w', encoding='utf-8') as f:
        json.dump(progress_data, f, indent=4)

# Function to fetch Hadith details with error handling and retries
def fetch_hadith_details(hadith_id, max_retries=3, timeout=30, use_minimal_headers=False):
    payload = {
        "hadithId": [hadith_id],  
        "searchPhrase": ""
    }
    
    for attempt in range(max_retries):
        try:
            # Use minimal headers if specified or if previous attempts failed
            headers = get_minimal_headers() if (use_minimal_headers or attempt > 0) else get_random_headers()
            session = get_requests_session(timeout=timeout)
            
            response = session.post(
                base_endpoints["hadith_details"], 
                json=payload, 
                headers=headers,
                timeout=timeout
            )
            
            if response.status_code == 200:
                return response.json()
            elif response.status_code == 430:  # Header fields too large
                logging.warning(f"Error 430: Request header fields too large. Retrying with minimal headers.")
                # Next attempt will use minimal headers
                time.sleep(5 * (attempt + 1))
                continue
            elif response.status_code == 429:  # Rate limit
                logging.warning(f"Rate limit hit, attempt {attempt+1}/{max_retries}")
                time.sleep(60 * (attempt + 1))  # Longer backoff for rate limits
            else:
                logging.warning(f"Failed with status {response.status_code}, attempt {attempt+1}/{max_retries}")
                time.sleep(10 * (attempt + 1))
                
        except requests.exceptions.RequestException as e:
            logging.error(f"Request error: {e}, attempt {attempt+1}/{max_retries}")
            # Check for specific timeout errors and implement exponential backoff
            if "timeout" in str(e).lower():
                wait_time = 30 * (2 ** attempt)  # Exponential backoff: 30s, 60s, 120s
                logging.warning(f"Connection timeout. Waiting {wait_time}s before retry.")
                time.sleep(wait_time)
            else:
                time.sleep(10 * (attempt + 1))
    
    return {"error": f"Failed after {max_retries} attempts"}

# Function to fetch Hadith Rejal list with error handling and retries
def fetch_hadith_rejal(hadith_id, max_retries=3, timeout=30, use_minimal_headers=False):
    endpoint = f"{base_endpoints['hadith_rejal']}?hadithId={hadith_id}"
    
    for attempt in range(max_retries):
        try:
            # Use minimal headers if specified or if previous attempts failed
            headers = get_minimal_headers() if (use_minimal_headers or attempt > 0) else get_random_headers()
            session = get_requests_session(timeout=timeout)
            
            response = session.get(
                endpoint, 
                headers=headers,
                timeout=timeout
            )
            
            if response.status_code == 200:
                return response.json()
            elif response.status_code == 430:  # Header fields too large
                logging.warning(f"Error 430: Request header fields too large. Retrying with minimal headers.")
                # Next attempt will use minimal headers
                time.sleep(5 * (attempt + 1))
                continue
            elif response.status_code == 429:  # Rate limit
                logging.warning(f"Rate limit hit, attempt {attempt+1}/{max_retries}")
                time.sleep(60 * (attempt + 1))  # Longer backoff for rate limits
            else:
                logging.warning(f"Failed with status {response.status_code}, attempt {attempt+1}/{max_retries}")
                time.sleep(10 * (attempt + 1))
                
        except requests.exceptions.RequestException as e:
            logging.error(f"Request error: {e}, attempt {attempt+1}/{max_retries}")
            # Check for specific timeout errors and implement exponential backoff
            if "timeout" in str(e).lower():
                wait_time = 30 * (2 ** attempt)  # Exponential backoff: 30s, 60s, 120s
                logging.warning(f"Connection timeout. Waiting {wait_time}s before retry.")
                time.sleep(wait_time)
            else:
                time.sleep(10 * (attempt + 1))
    
    return {"error": f"Failed after {max_retries} attempts"}

# Advanced adaptive waiting strategy to avoid getting banned
def adaptive_wait(progress, is_error=False):
    # Base delay range in seconds (random value between these values)
    min_delay = 5
    max_delay = 8
    
    # Get current delay factor (increases with errors and resets gradually with success)
    delay_factor = progress.get("delay_factor", 1.0)
    
    # Calculate wait time based on error patterns
    if is_error:
        # Increase delay factor when errors occur (exponential growth)
        delay_factor = min(delay_factor * 1.5, 10.0)  # Cap at 10x
        progress["delay_factor"] = delay_factor
        
        # Longer delays for errors
        base_wait = random.uniform(max_delay, max_delay * 1.5)
    else:
        # Gradually decrease delay factor on success (slow linear decrease)
        delay_factor = max(delay_factor * 0.95, 1.0)  # Don't go below 1.0
        progress["delay_factor"] = delay_factor
        
        # Normal delays for success
        base_wait = random.uniform(min_delay, max_delay)
    
    # Apply the delay factor
    wait_time = base_wait * delay_factor
    
    # Add additional delay for specific issues
    # Increase wait time if we've had consecutive failures
    if progress.get("consecutive_failures", 0) > 0:
        wait_time += progress.get("consecutive_failures", 0) * 2
    
    # Add more delay if we've seen header too large errors
    if progress.get("header_too_large_errors", 0) > 0:
        wait_time += progress.get("header_too_large_errors", 0) * 1.5
    
    # Add extra randomization to appear more human-like (±15% variation)
    wait_time = wait_time * random.uniform(0.85, 1.15)
    
    # Cap the maximum wait time to a reasonable value
    max_wait_cap = 45  # Maximum 45 seconds
    wait_time = min(wait_time, max_wait_cap)
    
    # Apply the wait
    logging.info(f"Waiting {wait_time:.2f} seconds before next request (delay factor: {delay_factor:.2f})")
    time.sleep(wait_time)
    
    return wait_time

# Main function to process all hadith IDs with anti-ban measures
def main():
    # Read hadith IDs from file
    all_hadith_ids = read_hadith_ids_from_file()
    if not all_hadith_ids:
        logging.error("No hadith IDs found in file. Exiting.")
        return
    
    # Load progress
    progress = load_progress()
    start_index = progress["last_processed_index"] + 1
    
    logging.info(f"Starting from index {start_index}, {len(all_hadith_ids) - start_index} IDs remaining")
    
    # Define rate limiting parameters
    requests_count = 0
    max_requests_per_session = 30  # Reduced from 40 to be even more conservative
    session_cooldown_minutes = random.randint(8, 15)  # Longer cooldown between sessions
    
    # Flag to track if we should use minimal headers due to 430 errors
    use_minimal_headers = progress.get("header_too_large_errors", 0) > 2
    
    # Time-of-day awareness (websites often have lower traffic at night)
    current_hour = datetime.now().hour
    night_time = 0 <= current_hour < 6  # Between midnight and 6 AM
    if night_time:
        logging.info("Running during night hours - slightly faster operation")
        max_requests_per_session = 35  # Can be a bit more aggressive at night
    
    for idx, hadith_id in enumerate(all_hadith_ids[start_index:], start=start_index):
        if hadith_id in progress["completed"]:
            logging.info(f"Skipping already processed hadith ID: {hadith_id}")
            continue
        
        # Check if we need a session cooldown
        if requests_count >= max_requests_per_session:
            cooldown_seconds = session_cooldown_minutes * 60
            logging.info(f"Reached max requests per session ({max_requests_per_session}). Cooling down for {session_cooldown_minutes} minutes...")
            time.sleep(cooldown_seconds)
            requests_count = 0
            session_cooldown_minutes = random.randint(8, 15)  # Randomize for next cooldown
        
        try:
            logging.info(f"Processing hadith ID: {hadith_id} ({idx+1}/{len(all_hadith_ids)})")
            
            # Fetch data with randomized delay between requests
            hadith_data = fetch_hadith_details(hadith_id, use_minimal_headers=use_minimal_headers)
            requests_count += 1
            
            # Check for rate limiting or errors
            if "error" in hadith_data:
                if "Failed after" in str(hadith_data["error"]):
                    progress["failed"].append(hadith_id)
                    progress["timeout_errors"] += 1
                    progress["consecutive_failures"] = progress.get("consecutive_failures", 0) + 1
                    save_progress(progress)
                    
                    # If we encounter too many timeout errors in a row, take a longer break
                    if progress["timeout_errors"] >= 3 or progress.get("consecutive_failures", 0) >= 5:
                        extended_cooldown = random.randint(5, 12) * 60
                        logging.warning(f"Multiple connection errors detected. Taking break for {extended_cooldown//60} minutes to allow server to recover")
                        time.sleep(extended_cooldown)
                        progress["timeout_errors"] = 0
                        progress["consecutive_failures"] = max(0, progress.get("consecutive_failures", 0) - 3)  # Reduce but don't reset completely
                    
                    continue
            
            # Use adaptive waiting strategy between requests
            wait_time = adaptive_wait(progress, is_error=False)
            
            # Reset error counters if successful
            progress["timeout_errors"] = 0
            progress["consecutive_failures"] = 0
            
            rejal_data = fetch_hadith_rejal(hadith_id, use_minimal_headers=use_minimal_headers)
            requests_count += 1
            
            # Check if rejal data fetch failed
            if "error" in rejal_data:
                if "Failed after" in str(rejal_data["error"]):
                    progress["consecutive_failures"] = progress.get("consecutive_failures", 0) + 1
                    wait_time = adaptive_wait(progress, is_error=True)
            else:
                progress["consecutive_failures"] = 0
                wait_time = adaptive_wait(progress, is_error=False)
            
            # Save complete response to JSON even if rejal data failed
            final_data = {
                "hadith_id": hadith_id,
                "hadith_details": hadith_data,
                "hadith_rejal_list": rejal_data,
                "timestamp": datetime.now().isoformat()
            }
            
            # Save JSON in the dedicated folder
            json_file = os.path.join(json_folder, f"hadith_{hadith_id}.json")
            with open(json_file, "w", encoding="utf-8") as file:
                json.dump(final_data, file, indent=4, ensure_ascii=False)
            
            logging.info(f"[SUCCESS] Hadith {hadith_id}: Complete data saved to '{json_file}'")
            
            # Mark as completed
            progress["completed"].append(hadith_id)
            
            # Update progress
            progress["last_processed_index"] = idx
            save_progress(progress)
            
            # Add a small random delay between storing data and starting next request
            time.sleep(random.uniform(1, 3))
            
        except Exception as e:
            logging.error(f"Unexpected error processing hadith {hadith_id}: {e}")
            
            # Check if the error is related to header size (Error 430)
            if "430" in str(e) or "header" in str(e).lower():
                progress["header_too_large_errors"] = progress.get("header_too_large_errors", 0) + 1
                use_minimal_headers = True
                logging.warning("Switching to minimal headers for future requests due to header size errors")
            
            progress["failed"].append(hadith_id)
            progress["last_processed_index"] = idx
            progress["consecutive_failures"] = progress.get("consecutive_failures", 0) + 1
            save_progress(progress)
            
            # Take a break after an unexpected error
            cooldown = random.uniform(15, 30)
            logging.info(f"Taking a {cooldown:.1f} second break after encountering an error")
            time.sleep(cooldown)
    
    logging.info("Processing completed")
    logging.info(f"Successful: {len(progress['completed'])}, Failed: {len(progress['failed'])}")

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        logging.info("Script manually interrupted")
    except Exception as e:
        logging.error(f"Critical error: {e}")
